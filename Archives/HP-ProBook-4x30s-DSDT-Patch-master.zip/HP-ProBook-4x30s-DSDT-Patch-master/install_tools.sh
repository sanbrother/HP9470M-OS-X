#!/bin/bash

./install_downloads.sh toolsonly
