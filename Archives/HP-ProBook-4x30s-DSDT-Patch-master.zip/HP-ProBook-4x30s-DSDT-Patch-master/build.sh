#!/bin/bash

./make_config.sh
./make_acpi.sh
./patch_hda.sh ProBook
