## Clover laptop config.plist and hotpatch

This project contains config.plist files for common laptops with Intel graphics.

It is linked by this guide: http://www.tonymacx86.com/el-capitan-laptop-support/148093-guide-booting-os-x-installer-laptops-clover.html

Refer to the guide for details on usage of the various system specfic config*.plist files.

--

There are also some handy SSDTs for use with Clover ACPI hotpatch (in conjunction with hotpatch/config.plist)

It is a work in progress... I have no guide to link for you.

If you understand ACPI, you may find the SSDTs and hotpatch/config.plist quite useful.

